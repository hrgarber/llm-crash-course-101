#!/usr/bin/env python3
"""
Simple HTTP server with hot reload capabilities.
This server adds appropriate headers to enable hot reloading.
"""

import http.server
import socketserver
import os
import time
from datetime import datetime

PORT = 53834
DIRECTORY = os.path.join(os.getcwd(), "website")

class HotReloadHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    """Custom HTTP request handler with hot reload support."""
    
    def __init__(self, *args, **kwargs):
        # Set the directory to serve files from
        super().__init__(*args, directory=DIRECTORY, **kwargs)
    
    def end_headers(self):
        """Add headers to support hot reloading."""
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("Access-Control-Allow-Origin", "*")
        super().end_headers()
    
    def log_message(self, format, *args):
        """Custom log message with timestamp."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{timestamp}] {self.address_string()} - {format % args}")

def run_server():
    """Run the HTTP server."""
    handler = HotReloadHTTPRequestHandler
    
    # Allow address reuse to avoid "Address already in use" errors
    socketserver.TCPServer.allow_reuse_address = True
    
    with socketserver.TCPServer(("0.0.0.0", PORT), handler) as httpd:
        print(f"Serving at http://localhost:{PORT}")
        print(f"Hot reload enabled - serving from {DIRECTORY}")
        print("Press Ctrl+C to stop the server")
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer stopped.")

if __name__ == "__main__":
    run_server()