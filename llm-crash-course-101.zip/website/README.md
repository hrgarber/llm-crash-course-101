# LLM Crash Course 101

A simple, interactive presentation for technical leaders to understand LLM deployment options.

## Quick Start

### Option 1: Simple Static Hosting (Easiest)

1. Extract the zip file to any location on your computer
2. Open the `index.html` file in any modern web browser

### Option 2: Using Python's Built-in Server (Recommended)

1. Extract the zip file to any location on your computer
2. Open a terminal/command prompt
3. Navigate to the extracted folder
4. Run: `python -m http.server 8000` (or any port number)
5. Open a browser and go to: `http://localhost:8000/index.html`

### Option 3: With Hot Reload (For Development)

1. Extract the zip file to any location on your computer
2. Open a terminal/command prompt
3. Navigate to the extracted folder
4. Run: `python hot_reload_server.py`
5. Open a browser and go to: `http://localhost:53834/index.html`
6. Any changes to HTML, CSS, or JS files will automatically reload the page

## Navigation

- Use the sidebar to jump to specific sections
- Use the arrow buttons at the bottom to navigate slides
- Toggle the sidebar with the ≡ button

## Content Overview

- Introduction to LLMs
- Foundational vs Open Source Models
- Local vs Hosted Deployment
- Running Models Locally
- Quantization
- Conclusion and Next Steps

## Technical Details

- Pure HTML, CSS, and JavaScript (no external dependencies)
- Mobile-responsive design
- Includes hot reload capability for development