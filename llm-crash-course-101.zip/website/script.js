// Hot reload functionality
function enableHotReload() {
    const RELOAD_INTERVAL = 2000; // Check every 2 seconds
    
    // Store timestamps of last modified files
    let lastModified = {
        css: '',
        js: '',
        html: ''
    };
    
    // Function to check if files have been modified
    async function checkForChanges() {
        try {
            // Check CSS file
            const cssResponse = await fetch('styles.css', { method: 'HEAD' });
            const cssLastModified = cssResponse.headers.get('Last-Modified');
            
            // Check JS file
            const jsResponse = await fetch('script.js', { method: 'HEAD' });
            const jsLastModified = jsResponse.headers.get('Last-Modified');
            
            // Check HTML file
            const htmlResponse = await fetch('index.html', { method: 'HEAD' });
            const htmlLastModified = htmlResponse.headers.get('Last-Modified');
            
            // If any file has changed, reload the page
            if (lastModified.css && (
                lastModified.css !== cssLastModified ||
                lastModified.js !== jsLastModified ||
                lastModified.html !== htmlLastModified
            )) {
                console.log('Changes detected, reloading...');
                window.location.reload();
                return;
            }
            
            // Update last modified timestamps
            lastModified.css = cssLastModified;
            lastModified.js = jsLastModified;
            lastModified.html = htmlLastModified;
            
        } catch (error) {
            console.error('Hot reload check failed:', error);
        }
        
        // Schedule next check
        setTimeout(checkForChanges, RELOAD_INTERVAL);
    }
    
    // Start checking for changes
    checkForChanges();
    console.log('Hot reload enabled - checking for changes every', RELOAD_INTERVAL, 'ms');
}

document.addEventListener('DOMContentLoaded', function() {
    // Enable hot reload
    enableHotReload();
    
    // DOM Elements
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const prevSlideBtn = document.getElementById('prev-slide');
    const nextSlideBtn = document.getElementById('next-slide');
    const slideIndicator = document.getElementById('slide-indicator');
    const slides = document.querySelectorAll('.slide');
    const navItems = document.querySelectorAll('.sidebar-nav li');
    const quantChart = document.getElementById('quantChart');
    
    // State
    let currentSlideIndex = 0;
    const totalSlides = slides.length;
    
    // Check if sidebar state is stored in localStorage
    const sidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
    if (sidebarCollapsed) {
        sidebar.classList.add('collapsed');
    }
    
    // Update slide indicator
    function updateSlideIndicator() {
        slideIndicator.textContent = `${currentSlideIndex + 1}/${totalSlides}`;
    }
    
    // Show slide by index
    function showSlide(index) {
        // Hide all slides
        slides.forEach(slide => {
            slide.classList.remove('active');
        });
        
        // Show the current slide
        slides[index].classList.add('active');
        
        // Update navigation
        navItems.forEach(item => {
            item.classList.remove('active');
        });
        
        // Update the active nav item
        const activeNavItem = document.querySelector(`.sidebar-nav li[data-slide="${index}"]`);
        if (activeNavItem) {
            activeNavItem.classList.add('active');
        }
        
        // Update indicator
        updateSlideIndicator();
        
        // Initialize charts if needed
        if (index === 4 && quantChart) {
            initQuantizationChart();
        }
    }
    
    // Navigate to previous slide
    function goToPrevSlide() {
        if (currentSlideIndex > 0) {
            currentSlideIndex--;
            showSlide(currentSlideIndex);
        }
    }
    
    // Navigate to next slide
    function goToNextSlide() {
        if (currentSlideIndex < totalSlides - 1) {
            currentSlideIndex++;
            showSlide(currentSlideIndex);
        }
    }
    
    // Toggle sidebar
    function toggleSidebar() {
        sidebar.classList.toggle('collapsed');
        localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
    }
    
    // Initialize Quantization Chart
    function initQuantizationChart() {
        if (!quantChart) return;
        
        // Check if chart is already initialized
        if (window.quantizationChart) {
            window.quantizationChart.destroy();
        }
        
        const ctx = quantChart.getContext('2d');
        window.quantizationChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['FP16', 'Q8_0', 'Q6_K', 'Q5_K', 'Q4_K', 'Q3_K', 'Q2_K'],
                datasets: [{
                    label: 'Model Quality',
                    data: [100, 98, 95, 92, 85, 75, 60],
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.3
                }, {
                    label: 'Model Size',
                    data: [100, 50, 37.5, 31.25, 25, 18.75, 12.5],
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        title: {
                            display: true,
                            text: 'Percentage (%)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Quantization Level'
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    },
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Quantization Impact: Quality vs Size'
                    }
                }
            }
        });
    }
    
    // Event Listeners
    sidebarToggle.addEventListener('click', toggleSidebar);
    
    prevSlideBtn.addEventListener('click', goToPrevSlide);
    
    nextSlideBtn.addEventListener('click', goToNextSlide);
    
    // Keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.key === 'ArrowLeft') {
            goToPrevSlide();
        } else if (e.key === 'ArrowRight') {
            goToNextSlide();
        }
    });
    
    // Navigation from sidebar
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const slideIndex = parseInt(this.getAttribute('data-slide'));
            currentSlideIndex = slideIndex;
            showSlide(currentSlideIndex);
            
            // On mobile, collapse sidebar after navigation
            if (window.innerWidth <= 768) {
                sidebar.classList.add('collapsed');
                localStorage.setItem('sidebarCollapsed', 'true');
            }
        });
    });
    
    // Initialize
    updateSlideIndicator();
    showSlide(currentSlideIndex);
    
    // Handle window resize
    window.addEventListener('resize', function() {
        // If window is small and sidebar is open, close it
        if (window.innerWidth <= 768 && !sidebar.classList.contains('collapsed')) {
            sidebar.classList.add('collapsed');
            localStorage.setItem('sidebarCollapsed', 'true');
        }
        
        // Resize chart if it exists
        if (window.quantizationChart) {
            window.quantizationChart.resize();
        }
    });
});